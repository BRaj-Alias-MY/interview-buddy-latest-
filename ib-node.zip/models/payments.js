/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('payments', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    mode: {
      type: DataTypes.ENUM('cc','dc','paypal','cheque'),
      allowNull: false
    },
    chequeNo: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    bankName: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    chequeImage: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    chequeClearedDate: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    price: {
      type: DataTypes.DECIMAL,
      allowNull: false
    },
    pgResponse: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    status: {
      type: DataTypes.ENUM('open','inprogress','sucess','failed'),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'payments'
  });
};
