/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const sub_domains = sequelize.define('sub_domains', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    domainId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'domain',
        key: 'id'
      }
    },
    subDomainName: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('active','inactive'),
      allowNull: false
    },
    createdAt: {
      type:  DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type:  DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'sub_domains'
  });
  sub_domains.associate = function(models) {
    sub_domains.belongsTo(models.domain, {foreignKey: 'domainId', targetKey: 'id'});
    sub_domains.hasMany(models.questions, {foreignKey: 'subDomainId', targetKey: 'id'});
  };
  return sub_domains;
};
