'use strict';
module.exports = (sequelize, DataTypes) => {
  const asynctest = sequelize.define (
    'asynctest',
    {
      InterviewId: DataTypes.INTEGER,
      q_title: DataTypes.STRING,
      ano: DataTypes.INTEGER,
      uid: DataTypes.STRING,
      videoURL: DataTypes.STRING,
      q_time: DataTypes.INTEGER,
      answer: DataTypes.STRING,
      userId: DataTypes.INTEGER,
      email: DataTypes.STRING,
      status: DataTypes.INTEGER,
      max_count: DataTypes.INTEGER,
      time_taken: DataTypes.STRING,
    },
    {}
  );
  asynctest.associate = function (models) {
    // associations can be defined here
  };
  return asynctest;
};
