/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  let interview_type_map_child = sequelize.define('interview_type_map_child', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    interviewTypeMapId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview_type_map',
        key: 'id'
      }
    },
    interviewTypeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview_types',
        key: 'id'
      }
    },
    avalbility:{
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview_type_map_child'
  });
  interview_type_map_child.associate = function(models) {
    interview_type_map_child.belongsTo(models.interview_types, {foreignKey: 'interviewTypeId', targetKey: 'id'});
  };
  return interview_type_map_child;
};
