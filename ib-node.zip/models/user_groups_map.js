/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  let user_groups_map = sequelize.define('user_groups_map', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    groupId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'user_groups',
        key: 'id'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'user_groups_map'
  });
  user_groups_map.associate = function(models) {
	  user_groups_map.belongsTo(models.users, {foreignKey: 'userId', targetKey: 'id'});
  };
  return user_groups_map;
};
