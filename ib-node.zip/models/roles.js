/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const roles = sequelize.define('roles', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    role_name: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    level: {
      type: DataTypes.INTEGER(11),
      allowNull: true
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'roles'
  });
  roles.associate = function(models) {
    // associations can be defined here
    roles.hasMany(models.users, {foreignKey: 'id', targetKey: 'roleId'});
    roles.hasMany(models.menu_access_map, {foreignKey: 'roleId', targetKey: 'id'});
  };
  return roles;
};
