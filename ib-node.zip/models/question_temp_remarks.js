/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const question_temp_remarks = sequelize.define('question_temp_remarks', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    questionTempId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'questions_temp',
        key: 'id'
      }
    },
    
    remarks: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('correct','wrong'),
      allowNull: false
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'question_temp_remarks'
  });
  question_temp_remarks.associate = function(models) {
    question_temp_remarks.belongsTo(models.questions_temp, {foreignKey: 'questionTempId', targetKey: 'id'});
    question_temp_remarks.belongsTo(models.users, {foreignKey: 'userId', targetKey: 'id'});
  };
  return question_temp_remarks;
};
