let app = require('express');
let router = app.Router();
let questions_temp = require('../models').questions_temp;
let question_temp_remarks = require('../models').question_temp_remarks;
let users = require('../models').users;
let questions = require('../models').questions;
let domain = require('../models').domain;
let subdomain = require('../models').sub_domains;
let exp_level = require('../models').exp_level;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;


router.post('/validate',async (req,res)=>{
    let st = true;
    let dataOfFull = req.body;
    for(let o=0;o<dataOfFull.length;o++){
        //============ question exist validation ============
        await questions_temp.findAndCountAll({ where: {question : dataOfFull[o].question.trim()} }).then(async questionCount=>{
            if(questionCount.count>0){
                st = false;
                dataOfFull[o].validation = 'Question already exist.';
            }else{
                //============domain validation===============
                await domain.findOne({ where: {domainName : dataOfFull[o].domain} }).then(async domaindata=>{
                    if(domaindata){
                        //================sub domain validation===========
                        dataOfFull[o].domainId = domaindata.id;
                        await subdomain.findOne({ where: {domainId : dataOfFull[o].domainId,subDomainName:dataOfFull[o].subDomain} }).then(async subdomaindata=>{
                            if(subdomaindata){
                                dataOfFull[o].subDomainId = subdomaindata.id;
                                //============== exp level validation =============
                                await exp_level.findOne({ where: {experiance : dataOfFull[o].expLevel} }).then(async expData=>{
                                    if(expData){
                                        dataOfFull[o].expLevelId = expData.id;
                                        dataOfFull[o].status='open';
                                        dataOfFull[o].userId=req.auth.userId;
                                        dataOfFull[o].mandatory = 0;
                                        dataOfFull[o].global = 1;
                                    }else{
                                        st = false;
                                        dataOfFull[o].validation = 'Expert level not exist in our Database.'; 
                                    }
                                });
                            }else{
                                st = false;
                                dataOfFull[o].validation = 'Sub Domain name not exist in our database.';
                            }
                        });
                        
                    }else{
                        st = false;
                        dataOfFull[o].validation = 'Domain name not exist in our database.';
                    }
                });
            }
        }).catch(err=>res.send({status:false,message:"please check the Uploaded Columns"}));
    }
	await res.send({'status' : st, 'message':dataOfFull});
});

router.post('/bulk-upload',async (req,res)=>{
    if(req.body.status && req.auth.access.addAccess){
        questions_temp.afterBulkCreate(function(model,options) {
            options.auth = req.auth ? req.auth.userId : 0;
        });
        await questions_temp.bulkCreate(req.body.message).then(data=>{
            res.send({'status' : true, 'message':'questions uploaded'});
        }).catch(function (err) {
            console.log(err);
            res.send({'status' : false, "message" : 'Fail'});
        });
    }else{
        console.log(req.body);
        let msg = req.body.status ? "Validation Failed." : "Un Authorized.";
        res.send({'status' : false, 'message':msg});
    }
});


router.get('/qc',(req,res)=>{
      if(req.auth.access.gridAccess){
            questions_temp.findAll({include: [{model:domain,duplicating: false},{model:subdomain,duplicating: false},{model:exp_level,duplicating: false},{model:users,duplicating: false} ] ,where:{status: 'open'}}).then(data=>{
                res.send({status:true,data:data,access:req.auth.access});
            }).catch(err=>{
                console.log(err)
                res.send({status:false,message:'Fail',access:req.auth.access});
            });
      }else{
            res.send({status:false,message:'un Autherized.', access:[req.auth.access]});
      }
})

router.get('/qc/:id',(req,res)=>{
    if(req.auth.access.gridAccess){
        question_temp_remarks.findAll({include:{model:users},where:{questionTempId:req.params.id}}).then(data=>{
            res.send({status:true,data:data});
        }).catch(err=>{
            res.send({status:false,message:'fail.'})
        })
    }else{
          res.send({status:false,message:'un Autherized.', access:[req.auth.access]});
    }
})

router.post('/qc',(req,res)=>{
      let id = req.body.id;
      let status = req.body.status;
      if(status == 'accept'){
            //======= insert data in to our questions table =============
            questions_temp.findOne({where:{id:id}}).then(ques=>{
                let q_s_l = ques.dataValues;
                q_s_l['status'] = 'active';
                q_s_l.id = null;
                  console.log(q_s_l);
                  questions.create(q_s_l).then(result=>{
                        questions_temp.update({status:status},{where:{id:id}}).then(up=>{
                              res.send({status:true,message:'success'});
                        })
                  }).catch({status:false,message:'not updated.'});
            }).catch(err=>{
                  res.send({status:false,message:'not updated.'});
            })
      }else{
            questions_temp.update({status:status},{where:{id:id}}).then(up=>{
                  res.send({status:true,message:'success'});
            }).catch(err=>{
                  res.send({status:false,message:'not updated.'});
            })  
      }
})


router.get('/questions-remarks-list',(req,res)=>{
    if(req.auth.access.gridAccess){
        questions_temp.findAll({include: [{model:domain,duplicating: false},{model:subdomain,duplicating: false},{model:exp_level,duplicating: false},{model:question_temp_remarks}],where:{status:'open',userId:{[Op.ne]: req.auth.userId}}}).then(data=>{
            res.send({status:true,data:data, access:[req.auth.access]});
        }).catch(err=>{
            console.log(err)
            res.send({status:false,message:'fail'})
        })
    }else{
        res.send({status:false,message:'un Autherized.', access:[req.auth.access]});
    }
})

router.post('/questions-remarks-list/:id',(req,res)=>{
    let userdata = req.body;
    if(req.auth.access.addAccess){
        question_temp_remarks.findOne({where:{questionTempId:req.params.id,userId:req.auth.userId}}).then(codd=>{
            if(codd){
                res.send({status:false,message:'data already submited.'})
            }else{
                question_temp_remarks.create({questionTempId:req.params.id,status:userdata.status,remarks:userdata.remarks,userId:req.auth.userId}).then(reu=>{
                    res.send({status:true,message:'success'})
                }).catch(err=>{
                    res.send({status:false,message:'fail'})
                })
            }
        }).catch(err=>{
            res.send({status:false,message:'fail'})
        })
    }else{
        res.send({status:false,message:'un Autherized.', access:[req.auth.access]});
    }
    
})


router.get('/',(req,res)=>{
    if(req.auth.access.gridAccess){
        questions_temp.findAll({include: [{model:domain,duplicating: false},{model:subdomain,duplicating: false},{model:exp_level,duplicating: false} ] ,where:{userId: req.auth.userId}}).then(data=>{
            res.send({status:true,data:data,access:req.auth.access});
        }).catch(err=>{
            res.send({status:false,message:'Fail',access:req.auth.access});
        });
    }else{
        res.send({status:false,message:'un Autherized.', access:[req.auth.access]});
    }
});

router.get('/:id',(req,res)=>{
    questions_temp.findAll({ include: [{model:domain,duplicating: false},{model:subdomain,duplicating: false},{model:exp_level,duplicating: false},{model:question_temp_remarks,include:{model:users}} ] ,where:{id: req.params.id}}).then(data=>{
        res.send({status:true,data:data});
    }).catch(err=>{
        res.send({status:false,message:'Fail'});
    });
})

router.post('/',(req,res)=>{
    if(req.auth.access.addAccess){
  
        sequelize.query("SELECT * FROM `questions_temp` where question='"+req.body.question+"' and userId="+req.auth.userId, { type: sequelize.QueryTypes.SELECT})
        .then(dataQuestion => {
            if(dataQuestion.length>0){
                res.send({status:false,message:'Question already exist.'});
            }else{
                questions_temp.afterCreate(function(model, options, done) {//hook1
                    model.auth = req.auth ? req.auth.userId : 0;
                });
                questions_temp.create({
                    question:req.body.question,
                    answer:req.body.answer,
                    expLevelId:req.body.expLevelId,
                    difficulty:req.body.difficulty,
                    mandatory:0,
                    global:1,
                    domainId:req.body.domainId,
                    subDomainId:req.body.subDomainId,
                    keywords:req.body.keywords,
                    time:req.body.time,
                    status:'open',
                    userId:req.auth.userId
                }).then(data=>{
                    res.send({'status' : true, 'message':'Question Created.'});
                }).catch(function (err) {
                    console.log(err);
                    res.send({'status' : false, "message" : 'Fail'});
                });
            }
        })
    }else{
        res.send({status:false,message:'un Autherized.'});
    }
});

module.exports = router;