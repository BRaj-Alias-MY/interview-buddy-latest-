let app = require('express');
let router = app.Router();
let questions = require('../models').questions;
let domain = require('../models').domain;
let subdomain = require('../models').sub_domains;
let exp_level = require('../models').exp_level;
let users = require('../models').users;
let roles = require('../models').roles;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;


router.get('/list/:domain/:subdomain',(req,res)=>{
    let userData = req.body;
    if(req.auth.organization){
        let qry = "SELECT id,question,difficulty FROM `questions` where (organizationId is null or organizationId = 1) and domainId=1 and subDomainId=1 and status='active'";
        questions.findAll({attributes:["id","question","difficulty"],where:{domainId:req.params.domain,subDomainId:req.params.subdomain,mandatory:1,[Op.or]: [{organizationId: req.auth.organization}, {organizationId: null}]}}).then(mandate=>{
            //let dat = [];
            //dat.push({mandate:mandate});
            questions.findAll({attributes:["id","question","difficulty"],where:{domainId:req.params.domain,subDomainId:req.params.subdomain,[Op.or]: [{organizationId: req.auth.organization}, {organizationId: null}]}}).then(allques=>{
                let dat = {all:allques,mandate:mandate};
                res.send({status:true,data:dat});
            })
        })
    }else{
        res.send({status:false,message:"No Data",data:[]});
    }
});
//=========== validate questions ====================
router.post('/validate',async (req,res)=>{
    let st = true;
    let dataOfFull = req.body;
    for(let o=0;o<dataOfFull.length;o++){
        //============ question exist validation ============
        if(dataOfFull[o].question.trim()){
            await questions.findAndCountAll({ where: {question : dataOfFull[o].question.trim()} }).then(async questionCount=>{
                if(questionCount.count>0){
                    st = false;
                    dataOfFull[o].validation = 'Question already exist.';
                }else{
                    //============domain validation===============
                    await domain.findOne({ where: {domainName : dataOfFull[o].domain} }).then(async domaindata=>{
                        if(domaindata){
                            //================sub domain validation===========
                            dataOfFull[o].domainId = domaindata.id;
                            await subdomain.findOne({ where: {domainId : dataOfFull[o].domainId,subDomainName:dataOfFull[o].subDomain} }).then(async subdomaindata=>{
                                if(subdomaindata){
                                    dataOfFull[o].subDomainId = subdomaindata.id;
                                    //============== exp level validation =============
                                    await exp_level.findOne({ where: {experiance : dataOfFull[o].expLevel} }).then(async expData=>{
                                        if(expData){
                                            dataOfFull[o].expLevelId = expData.id;
                                            dataOfFull[o].status='active';
                                            dataOfFull[o].organizationId=req.auth.organization;
                                            dataOfFull[o].userId=req.auth.userId;
                                        }else{
                                            st = false;
                                            dataOfFull[o].validation = 'Expert level not exist in our Database.'; 
                                        }
                                    });
                                }else{
                                    st = false;
                                    dataOfFull[o].validation = 'Sub Domain name not exist in our database.';
                                }
                            });
                            
                        }else{
                            st = false;
                            dataOfFull[o].validation = 'Domain name not exist in our database.';
                        }
                    });
                }
            }).catch(err=>res.send({status:false,message:"please check the Uploaded Columns"}));
        }
    }
    st = dataOfFull.length>0 ? st : false;
	await res.send({'status' : st, 'message':dataOfFull});
});

router.post('/bulk-upload',async (req,res)=>{
    if(req.body.status){
        questions.afterBulkCreate(function(model,options) {
            options.auth = req.auth ? req.auth.userId : 0;
        });
        await questions.bulkCreate(req.body.message).then(data=>{
            res.send({'status' : true, 'message':'Questions uploaded'});
        }).catch(function (err) {
            console.log(err);
            res.send({'status' : false, "message" : 'Fail'});
        });
    }else{
        console.log(req.body);
        res.send({'status' : false, 'message':"Validation Failed."});
    }
});

router.get('/',(req,res)=>{
    if(req.auth.access.gridAccess && !req.auth.organization){
        questions.findAll({ include: [{model:domain,duplicating: false},{model:subdomain,duplicating: false},{model:exp_level,duplicating: false},{model:users,duplicating: false,include:{model:roles}} ] ,where:{organizationId: {[Op.eq]: null}}}).then(data=>{
            res.send({status:true,"data" : data, access:req.auth.access});
        }).catch(err=>{
            res.send({status:false,message:'Fail',access:req.auth.access});
        });
    }else if(req.auth.access.gridAccess){
        questions.findAll({include: [{model:domain,duplicating: false},{model:subdomain,duplicating: false},{model:exp_level,duplicating: false},{model:users,duplicating: false} ] ,where:{organizationId: req.auth.organization}}).then(data=>{
            res.send({status:true,data:data,access:req.auth.access});
        }).catch(err=>{
            res.send({status:false,message:'Fail',access:req.auth.access});
        });
    }else{
        res.send({status:false,message:'un Autherized.', access:[req.auth.access]});
    }
});

router.get('/:id',(req,res)=>{
    questions.findAll({ include: [{model:domain,duplicating: false},{model:subdomain,duplicating: false},{model:exp_level,duplicating: false} ] ,where:{id: req.params.id}}).then(data=>{
        res.send({status:true,data:data});
    }).catch(err=>{
        res.send({status:false,message:'Fail'});
    });
})

router.post('/',(req,res)=>{
    let apdGetQry;
    if(req.auth.access.addAccess && !req.auth.organization){
        apdGetQry = " and organizationId is null";
    }else if(req.auth.access.addAccess){
        apdGetQry = " and organizationId = "+req.auth.organization;
    }
    if(apdGetQry){
        sequelize.query("SELECT * FROM `questions` where question='"+req.body.question.trim()+"' "+apdGetQry, { type: sequelize.QueryTypes.SELECT})
        .then(dataQuestion => {
            if(dataQuestion.length>0){
                res.send({status:false,message:'Question already exist.'});
            }else{
                questions.afterCreate(function(model, options, done) {//hook1
                    model.auth = req.auth ? req.auth.userId : 0;
                });
                questions.create({
                    question:req.body.question.trim(),
                    answer:req.body.answer,
                    expLevelId:req.body.expLevelId,
                    difficulty:req.body.difficulty,
                    mandatory:req.body.mandatory,
                    global:req.body.global,
                    domainId:req.body.domainId,
                    subDomainId:req.body.subDomainId,
                    keywords:req.body.keywords,
                    time:req.body.time,
                    status:'active',
                    organizationId:req.auth.organization,
                    userId:req.auth.userId
                }).then(data=>{
                    res.send({'status' : true, 'message':'Question Created.'});
                }).catch(function (err) {
                    console.log(err);
                    res.send({'status' : false, "message" : 'Fail'});
                });
            }
        })
    }else{
        res.send({status:false,message:'un Autherized.'});
    }
});

router.post('/:id',(req,res)=>{
        if(req.auth.access.editAccess){
            let apdGetQry;
        if(req.auth.access.addAccess && !req.auth.organization){
            apdGetQry = " and organizationId is null";
        }else if(req.auth.access.addAccess){
            apdGetQry = " and organizationId = "+req.auth.organization;
        }
        sequelize.query("SELECT * FROM `questions` where question='"+req.body.question.trim()+"' and id!="+req.params.id+" "+apdGetQry, { type: sequelize.QueryTypes.SELECT})
        .then(dataQuestion => {
            if(dataQuestion.length>0){
                res.send({status:false,message:'Question already exist.'});
            }else{
                questions.afterBulkUpdate(function(options) {//hook1
                    options.auth = req.auth ? req.auth.userId : 0;
                });
                questions.update({
                    question:req.body.question.trim(),
                    answer:req.body.answer,
                    expLevelId:req.body.expLevelId,
                    difficulty:req.body.difficulty,
                    mandatory:req.body.mandatory,
                    global:req.body.global,
                    domainId:req.body.domainId,
                    subDomainId:req.body.subDomainId,
                    time:req.body.time,
                    keywords:req.body.keywords
                },{where:{id:req.params.id}}).then(res1=>{
                    res.send({'status' : true, 'message':'Question Updated.'});
                }).catch(err=>{
                    console.log(err);
                    res.send({'status' : false, 'message':'Fail.'});
                });
            }
        })
    }else{
        res.send({status:false,message:'Invalide Request.'});
    }
});

module.exports = router;