import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../app.service';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';

declare var $: any;
@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
  mydata:any;
  
  constructor(private service: AppService) { }

  // public radarChartLabels = [];
  // public radarChartData = [
  //   {data: [], label: 'EXP1'}
  // ];
  //public radarChartType = 'radar';
  public radarChartType = 'polarArea';

  reviewId = localStorage.getItem('vid');
  ngOnInit() {
    this.mydata = [];
    this.getReviews();

  }
  getReviews() {
    this.service.getReviews1(this.reviewId).subscribe(resp => { this.mydata = resp;this.addjestcontent() }, err => console.log(err));
  }

  addjestcontent(){
    let data = this.mydata.data;
    for(let i=0;i<data.length;i++){
      let totrev = 0;
      let totquerev = 0;
      let radarChartLabels = [];
      let radarChartData = [
        {data: [], label: 'EXP1'}
      ];
      for(let j=0;j<data[i].interview_expert_overall_feedbacks.length;j++){
        totrev+=Number(data[i].interview_expert_overall_feedbacks[j].rating);
        radarChartData[0].data[j] = Number(data[i].interview_expert_overall_feedbacks[j].rating);
        radarChartLabels[j] = data[i].interview_expert_overall_feedbacks[j].report_perameter.name;
      }
      for(let k=0;k<data[i].interview_experts_feedbacks.length;k++){
        totquerev+=Number(data[i].interview_experts_feedbacks[k].rating);
        console.log(totquerev)
      }
      let avgrat = ((totrev)/data[i].interview_expert_overall_feedbacks.length)/2;
      this.mydata.data[i].avgrat = avgrat.toFixed(1);
      let avgquerat = ((totquerev)/data[i].interview_experts_feedbacks.length);
      this.mydata.data[i].avgquerat = avgquerat.toFixed(1);
      let overall = ((Number(avgrat)+Number(avgquerat))/2).toFixed(1)
      this.mydata.data[i].overallrevRat = overall;
      this.mydata.data[i].radarChartData = radarChartData;
      this.mydata.data[i].radarChartLabels = radarChartLabels;
    }
  }

  public generatePDF() {
    var data = document.getElementById('contentToConvert');
    html2canvas(data).then(canvas => {
      // Few necessary setting options
      var imgWidth = 208;
      var pageHeight = 295;
      var imgHeight = canvas.height * imgWidth / canvas.width;
      var heightLeft = imgHeight;

      const contentDataURL = canvas.toDataURL('image/png')
      let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF
      var position = 0;
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
      let date1 = new Date();
      pdf.save('Report '+date1+'.pdf'); // Generated PDF
    });
  }

}
