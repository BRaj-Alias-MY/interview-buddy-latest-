import { Component, OnInit } from "@angular/core";
import { Route, Router } from "@angular/router";
import { MatDialogRef } from "@angular/material";
import { Userprofile2Component } from "../userprofile2/userprofile2.component";
import { HttpClient } from "@angular/common/http";
import { BsDatepickerConfig } from "ngx-bootstrap/datepicker";
import {
  FormControl,
  FormGroup,
  FormBuilder,
  Validators
} from "@angular/forms";
import { Education } from "../education/education";
import { DatePipe } from "@angular/common";

declare var $: any;
@Component({
  selector: "app-education",
  templateUrl: "./education.component.html",
  styleUrls: ["./education.component.css"]
})
export class EducationComponent implements OnInit {
  myDateValue: Date;
  myDateValue2: Date;
  educationForm: FormGroup;
  result: any;
  successmsg: any;
  education: Education;
  datePickerConfig: Partial<BsDatepickerConfig>;
  EDU_URL = "http://localhost:3000/api/userprofile/saveedu2";
  isDisabled = false;
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private http: HttpClient,
    public dialogRef: MatDialogRef<Userprofile2Component>
  ) {
    this.education = new Education();

    this.datePickerConfig = Object.assign(
      {},
      {
        containerClass: "theme-dark-blue",
        showWeekNumbers: false,
        minDate: this.myDateValue
      }
    );
  }
  userId = localStorage.getItem("userId");
  ngOnInit() {
    this.myDateValue = new Date();
    this.myDateValue2 = new Date();
    this.userId = localStorage.getItem("userId");
    //alert(this.userId);
    this.educationForm = this.fb.group({
      education: ["", Validators.required],
      userId: [this.userId],
      userProfileId: [this.userId],
      university: ["", Validators.required],
      courseFrom: ["", Validators.required],
      courseTo: ["", Validators.required],
      specilization: ["", Validators.required],
      grade: ["", Validators.required]
    });
  }
  close() {
    // alert('test');
    this.dialogRef.close("Thanks for using me!");
    //  window.location.reload();
  }
  success() {
    this.router.navigate(["/examboard2/testsetup2"]);
    this.dialogRef.close("Thanks for using me!");
  }
  onDateChange(newDate: Date) {
    console.log(newDate);
  }
  onChange(event) {
    alert(event.target.value);
  }
  onEducation() {
    this.isDisabled = true;
    this.education = this.educationForm.value;
    this.http.post<any>(this.EDU_URL, this.education).subscribe(
      resp => {
        console.log(resp["message"]);
        if (resp["message"] == "Exists") {
          // alert('ok');
          this.successmsg = "Education Title Should be Unique. Already Exists!";
        } else {
          this.successmsg = "Added Successfully";
        }
        console.log(resp);
        this.isDisabled = false;
      },
      err => console.log(err),
      () => {
        this.isDisabled = false;
      }
    );
  }
}
