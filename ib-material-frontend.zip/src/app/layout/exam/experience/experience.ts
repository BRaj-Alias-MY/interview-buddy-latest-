export class Experience {
    userProfileId: number;
    organizationName: string;
    desgination: string;
    joinedDate: string;
    relivedDate: string;
}