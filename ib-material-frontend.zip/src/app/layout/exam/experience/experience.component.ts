import { Component, OnInit } from "@angular/core";
import { Route, Router } from "@angular/router";
import { MatDialogRef } from "@angular/material";
import {
  FormControl,
  FormGroup,
  FormBuilder,
  Validators
} from "@angular/forms";
import { Userprofile2Component } from "../userprofile2/userprofile2.component";
import { HttpClient } from "@angular/common/http";
import { Experience } from "../experience/experience";
declare var $: any;
@Component({
  selector: "app-experience",
  templateUrl: "./experience.component.html",
  styleUrls: ["./experience.component.css"]
})
export class ExperienceComponent implements OnInit {
  experience: Experience;
  myDateValue: Date;
  myDateValue2: Date;
  userId = localStorage.getItem("userId");
  expForm: FormGroup;
  successmsg: any;
  isDisabled = false;
  EXP_URL = "http://localhost:3000/api/userprofile/saveexp2";
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private http: HttpClient,
    public dialogRef: MatDialogRef<Userprofile2Component>
  ) {
    this.experience = new Experience();
  }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    this.myDateValue = new Date();
    this.myDateValue2 = new Date();
    this.expForm = this.fb.group({
      userId: [this.userId],
      userProfileId: [this.userId],
      organizationName: ["", Validators.required],
      desgination: ["", Validators.required],
      joinedDate: ["", Validators.required],
      relivedDate: ["", Validators.required]
    });
  }
  onExperience() {
    this.isDisabled = true;
    this.experience = this.expForm.value;
    if (this.experience != null) {
      this.http.post<any>(this.EXP_URL, this.experience).subscribe(
        resp => {
          console.log(resp["message"]);
          if (resp["message"] == "Exists") {
            // alert('ok');
            this.successmsg =
              "Experiance Title Should be Unique. Already Exists!";
          } else {
            this.successmsg = "Added Successfully";
          }
          console.log(resp);
          this.experience = null;
          this.isDisabled = false;
        },
        err => console.log(err)
      );
    }
  }
  close() {
    //alert('test');
    this.dialogRef.close("Thanks for using me!");
    //window.location.reload();
  }
}
