import { Component, OnInit } from "@angular/core";
import { FormControl, FormGroup, FormBuilder } from "@angular/forms";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { EducationComponent } from "../education/education.component";
import { ExperienceComponent } from "../experience/experience.component";
import {
  FileUploader,
  FileSelectDirective
} from "ng2-file-upload/ng2-file-upload";
import { HttpClient } from "@angular/common/http";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { Router } from "@angular/router";
import { Profile } from "../userprofile2/profile";
import { ApiService } from "../../../services/api.service";

const URL = "http://localhost:3000/api/userprofile/upload";

@Component({
  selector: "app-userprofile2",
  templateUrl: "./userprofile2.component.html",
  styleUrls: ["./userprofile2.component.css"]
})
export class Userprofile2Component implements OnInit {
  profileForm: FormGroup;
  userId = localStorage.getItem("userId");
  userprofile: Profile;
  email = localStorage.getItem("email");
  result: any;
  students: any[];
  studentsdata: any[] = [{}];
  edu = [];
  exp = [];
  baseUrl = "http://localhost:3000/api/";
  GET_EDU_URL = this.baseUrl + "userprofile/getedu/" + this.userId;
  GET_EXP_URL = this.baseUrl + "userprofile/getexp/" + this.userId;
  DELETE_EDU_URL = this.baseUrl + "userprofile/deleteedu/";
  DELETE_EXP_URL = this.baseUrl + "userprofile/deleteexp/";
  PROFILE_URL = this.baseUrl + "userprofile/saveprofile2/";
  POST_FILE_URL = this.baseUrl + "userprofile/upload/";
  GET_URL =
    this.baseUrl + "userprofile/getprofile/" + localStorage.getItem("userId");
  constructor(
    private api: ApiService,
    private router: Router,
    private http: HttpClient,
    private dialog: MatDialog,
    private fb: FormBuilder
  ) {
    this.userprofile = new Profile();

    this.http.get<any>(this.GET_URL).subscribe(
      res => {
        this.userprofile = res;
        this.userprofile.about = res[0]["about"];
        this.userprofile.adress = res[0]["adress"];
        this.userprofile.pincode = res[0]["pincode"];
        this.userprofile.linkedinId = res[0]["linkedinId"];
        //alert(res[0]["about"]);
        console.log(this.userprofile);
      },
      err => {
        console.log(err);
      }
    );
  }
  selectedFile: File;

  public uploader: FileUploader = new FileUploader({
    url: URL,
    itemAlias: "doc",
    headers: [{ name: "authorization", value: localStorage.getItem("token") }]
  });

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    this.email = localStorage.getItem("email");

    this.http.get<any>(this.GET_URL).subscribe(
      res => {
        this.userprofile = res;

        this.userprofile.about = res[0]["about"];
        this.userprofile.adress = res[0]["adress"];
        this.userprofile.pincode = res[0]["pincode"];
        this.userprofile.linkedinId = res[0]["linkedinId"];
        //        alert(res["about"]);
        console.log(this.userprofile);
      },
      err => {
        console.log(err);
      }
    );

    this.uploader.onAfterAddingFile = file => {
      file.withCredentials = false;
    };
    this.uploader.onCompleteItem = (
      item: any,
      response: any,
      status: any,
      headers: any
    ) => {
      console.log("FileUpload:uploaded:", item, status, response);
      alert("File uploaded successfully");
      // this.btn_name = "Save";
    };
    this.http.get<any[]>(this.GET_EDU_URL).subscribe(
      res => {
        this.edu = res;
        console.log(res);
      },
      err => {
        console.log(err);
      }
    );
    this.http.get<any[]>(this.GET_EXP_URL).subscribe(
      res => {
        this.exp = res;
        console.log(res);
      },
      err => {
        console.log(err);
      }
    );

    //alert(this.userId);
    this.profileForm = this.fb.group({
      about: [""],
      userId: [this.userId],
      adress: [""],
      pincode: [""],
      linkedinId: [""],
      resume: [""]
    });
  }
  onSubmit() {
    this.userprofile = this.profileForm.value;
    this.http.post<any>(this.PROFILE_URL, this.userprofile).subscribe(
      res => {
        this.result = "Profile Updated Successfully!";
        console.log(res);
        //this.userprofile.resume = ;
      },
      err => console.log(err)
    );
    // this.http.post<any>(this.POST_FILE_URL,resume)
    //console.log(this.profileForm['resume']);
  }
  logout() {
    this.api.logout();
    this.router.navigate(["/login"]);
  }

  getEdu() {
    this.http.get<any[]>(this.GET_EDU_URL).subscribe(
      res => {
        this.edu = res;
        console.log(res);
      },
      err => {
        console.log(err);
      }
    );
  }
  getExp() {
    this.http.get<any[]>(this.GET_EXP_URL).subscribe(
      res => {
        this.exp = res;
        console.log(res);
      },
      err => {
        console.log(err);
      }
    );
  }

  openDialog() {
    this.dialog
      .open(EducationComponent, {
        width: "90%",
        disableClose: true
      })
      .afterClosed()
      .subscribe(
        result => {
          console.log(result);
          console.log("hooo");
          this.getEdu();
        },
        err => console.log(err)
      );
  }
  openDialog2() {
    this.dialog
      .open(ExperienceComponent, {
        width: "90%",
        disableClose: true
      })
      .afterClosed()
      .subscribe(
        result => {
          console.log(result);
          console.log("hooo222");
          this.getExp();
        },
        err => console.log(err)
      );
  }
  deleteEdu(id, education) {
    //alert(id);
    return Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete it?",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Delete it!",
      cancelButtonText: "No, keep it"
    }).then(result => {
      if (result.value) {
        this.http.get(this.DELETE_EDU_URL + id + "/" + education).subscribe(
          res => {
            Swal.fire({
              type: "success",
              title: "Deleted!",
              text: "The Record has been deleted."
            });
            console.log(res);
          },
          err => {
            console.log(err);
          },
          () => {
            this.getEdu();
          }
        );

        return this.router.navigate(["/examboard2/userprofile2"]);
        Swal.fire("Success", "Your imaginary data is safe :)", "success");
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire("Cancelled", "Your imaginary data is safe :)", "error");
      }
    });
  }
  deleteExp(id, organizationName) {
    //  alert(id);
    //this.http.get(this.DELETE_EXP_URL + id + '/' + organizationName).subscribe(res => console.log(res), err => console.log(err), () => this.getExp());

    Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete it?",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Delete it!",
      cancelButtonText: "No, keep it"
    }).then(result => {
      if (result.value) {
        this.http
          .get(this.DELETE_EXP_URL + id + "/" + organizationName)
          .subscribe(
            res => {
              console.log(res);
              Swal.fire({
                type: "success",
                title: "Deleted!",
                text: "The Record has been deleted."
              });
              console.log(res);
            },
            err => console.log(err),
            () => this.getExp()
          );
        // return window.location.href = "/examboard2/userprofile2";
        return true;
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire("Cancelled", "Your imaginary data is safe :)", "error");
      }
    });
  }
}
