export class Profile {
    about: string;
    adress: string;
    pincode: string;
    linkedinId: string;
    resume: string;
}