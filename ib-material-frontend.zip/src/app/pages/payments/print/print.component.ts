import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { PaymentsService } from '../services/payments.service';
import {ActivatedRoute} from "@angular/router";
import Swal from 'sweetalert2/dist/sweetalert2.js';

@Component({
  selector: 'app-print',
  templateUrl: './print.component.html',
  styleUrls: ['./print.component.css']
})
export class PrintComponent implements OnInit {
  pay_id : number;
  paymentData : any[];
  constructor(private publicApi:ApiService,private api: PaymentsService, private route: ActivatedRoute) { 
    this.route.params.subscribe( params => this.pay_id = params.id );
  }

  ngOnInit() {
    this.paymentData = [];
    this.api.getPrint(this.pay_id).subscribe(data=>{
      this.paymentData = data;
      if(!data.status){
        Swal.fire('Oops..',data.message,'error');
      }
    })
  }

}
