import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ApiService} from '../../../services/api.service';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import {MastersService} from '../services/masters.service';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-organizationprofile',
  templateUrl: './organizationprofile.component.html',
  styleUrls: ['./organizationprofile.component.css']
})
export class OrganizationprofileComponent implements OnInit {

  constructor(private fb: FormBuilder, private api:ApiService, private apinew : MastersService ) { }
  roles;
  key;
  id;
  access;
  ngOnInit() {
    this.key = this.api.getToken() ? this.api.getToken() : '';
    if(this.api.getUser()){
    let user = this.api.getUser()
    console.log(user);
    this.id = user.organizationId;
    this.getorgdetails();
 }

  }
 
getorgdetails(){
  console.log(this.id);
   this.apinew.get_org_details(this.id).subscribe((data) => {
    this.access = data.data;
    });  
}

}
