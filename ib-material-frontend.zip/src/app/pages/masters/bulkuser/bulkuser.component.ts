import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import {ApiService} from '../../../services/api.service';
import { MastersService } from '../services/masters.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import {ExcelService} from '../../../services/excel.service';

@Component({
	selector: 'app-bulkuser',
	templateUrl: './bulkuser.component.html',
	styleUrls: [ './bulkuser.component.css' ]
})
export class BulkuserComponent implements OnInit {
	public csvRecords: any[] = [];
	public csvRecords1 = [];
	data: any = [{
		"fname": '',"mname": "","lname": "","email": "","phone": "","gender": "","subDomainName":""
	}];
    constructor(private fb: FormBuilder, private route: Router, private api: MastersService, private api_main:ApiService,private excelService: ExcelService) {}
	buttonStatus;
	responsedata;
	usrgrp;
	blkusr;
	key; 
	bulkuser: boolean;

	ngOnInit() {
		this.buttonStatus = false;
		this.key = this.api_main.getToken() ? this.api_main.getToken() : '';
		if(this.api_main.getUser()){
		let user = this.api_main.getUser()
		console.log(user.role.id);
		if(user.role.id == 4)
		{
		  this.bulkuser = this.bulkuser ? false : true;
		}
		else{
		  this.bulkuser = this.bulkuser ? false : false;
		}
		
	 }
	
		this.api.get_user_groups().subscribe(res=> this.usrgrp = res.data);

	}

	bulkusrForm = this.fb.group({
		id:[],
		user_groups: ['']
		 }); 
    
	@ViewChild('fileImportInput') fileImportInput: any;
	fileChangeListener($event: any): void {
		var text = [];
		var files = $event.srcElement.files;

		if (this.isCSVFile(files[0])) {
			var input = $event.target;
			var reader = new FileReader();
			reader.readAsArrayBuffer(input.files[0]);

			reader.onload = (data) => {
				let csvData1 : any = reader.result;
				let csvData = this.excelService.importExcel(csvData1);
				let csvRecordsArray = (csvData as string).split(/\r\n|\n/);

				let headersRow = this.getHeaderArray(csvRecordsArray);

				this.csvRecords = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
			};

			reader.onerror = function() {
				Swal('Unable to read ' + input.files[0]);
			};
		} else {
			Swal('Please import valid .csv file.');
			this.fileReset();
		}
	}
	getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
		var dataArr = [];

		for (let i = 1; i < csvRecordsArray.length; i++) {
			//let data = (csvRecordsArray[i] as string).split(',');
			let data = csvRecordsArray[i].match(/("[^"]*")|[^,]+/g);
			// FOR EACH ROW IN CSV FILE IF THE NUMBER OF COLUMNS
			// ARE SAME AS NUMBER OF HEADER COLUMNS THEN PARSE THE DATA
			if (data) {
				if (data.length == headerLength) {
					var csvRecord: CSVRecord = new CSVRecord();

					csvRecord.fname = data[0].trim();
					csvRecord.mname = data[1].trim();
					csvRecord.lname = data[2].trim();
					csvRecord.email = data[3].trim();
					csvRecord.phone = data[4].trim();
					csvRecord.gender = data[5].trim();
					csvRecord.subDomainName = data[6].trim();

					dataArr.push(csvRecord);
				}
			}
		}
		let dupStatus = false;
		for (let i = 0; i < dataArr.length; i++) {
			// console.log(dataArr[i].question);
			for (let j = i + 1; j < dataArr.length; j++) {
				if (dataArr[i].email == dataArr[j].email) {
					dupStatus = true;
					break;
				}
			}
		}
		if (dupStatus) {
			//Swal('Duplicate Data.');
			//alert('Duplicate Data.');
		} else {
			console.log(dataArr);

			this.api.valid_users(dataArr).subscribe((res) => {
				if (res.status) {
					this.buttonStatus = res.status;
					this.csvRecords1 = res.message;
					this.responsedata = res;
				} else {
					this.csvRecords1 = res.message;
					this.fileReset();
					// console.log(this.csvRecords1);
					if(this.csvRecords1.length>0){
						Swal.fire('Oops..', 'Please find the Validation Column', 'error');
					 }else{
						Swal.fire('Oops..', 'No data found in file. please upload valid file', 'error');
					 }

				}
			});
			//console.log('hell0');
		
		}
		return dataArr;
	}
	// CHECK IF FILE IS A VALID CSV FILE
	isCSVFile(file: any) {
		return file.name.endsWith('.xlsx');
	}
	// GET CSV FILE HEADER COLUMNS
	getHeaderArray(csvRecordsArr: any) {
		let headers = (csvRecordsArr[0] as string).split(',');
		let headerArray = [];

		for (let j = 0; j < headers.length; j++) {
			headerArray.push(headers[j]);
		}
		return headerArray;
	}

	fileReset() {
		this.fileImportInput.nativeElement.value = '';
		this.csvRecords = [];
	}
	onSubmit(data) {
		 let blkusr = this.bulkusrForm.value.user_groups;
		 blkusr = blkusr.length>0 ? blkusr : [];
		 this.responsedata.user_groups = blkusr;
		console.log(this.responsedata);
         this.api.add_users(this.responsedata).subscribe((res) => {
			if (res.status) {
				//alert('sucess');
				Swal.fire('Success..', 'Users Uploaded successfully', 'success'); 
				this.fileReset();
				this.csvRecords1 = [];
				this.bulkusrForm.patchValue({user_groups: '' });
				this.buttonStatus = false;

			} else {
				//this.csvRecords1 = res.message;
				// console.log(this.csvRecords1);
				Swal.fire('Oops...', 'Something went wrong!', 'error');

			}
		});  
	}

	downtemp() : void{
		this.api.get_basicinfo().subscribe(ddata=>{
			let dmnslist = [];
			ddata.data.domain.forEach(element => {
				element.sub_domains.forEach(element1 => {
					dmnslist.push({Domain:element.domainName,Subdomain:element1.subDomainName});
				});
			});
			let gender = [{Gender:'male'},{Gender:'female'}];
			
			let senddata = [{sheetname:'Data',sheetvalue:this.data},{sheetname:'DomainsList',sheetvalue:dmnslist},{sheetname:'Gender',sheetvalue:gender}];
			this.excelService.exportAsExcelFile(senddata ,'Bulk User Upload')
		});
	}
}

export class CSVRecord {
	public fname: any;
	public mname: any;
	public lname: any;
	public email: any;
	public phone: any;
	public gender: any;
	public subDomainName:any;
}
