import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import {MastersService} from '../services/masters.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer }  from '../../../childmessagerender.component';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import {ApiService} from '../../../services/api.service';

@Component({
  selector: 'app-questionsreview',
  templateUrl: './questionsreview.component.html',
  styleUrls: ['./questionsreview.component.css']
})
export class QuestionsreviewComponent implements OnInit {
rev;
review;
access; 
view_item: any;
viewSt:boolean;
qsnreview;
formstat:boolean;
constructor(private fb: FormBuilder, private route: Router, private api: MastersService, public publicapi:ApiService) {}
reviewForm = this.fb.group({
  id:[],
  status: [''],
  remarks:['']

});
  ngOnInit() {
    this.viewSt = false;
    this.review = {};
    this.qsnreview=[];
    this.view_item = [];
    this.formstat = false;
    this.grid();
    this.access = {addAccess: 0, editAccess: 0,deleteAccess:0,gridAccess:0};

    /* this.api.get_questionreview().subscribe(data=>{
      this.review = data;
      console.log( this.review);
  }); */
  }
  ViewItem(item_id) {
		this.view_item.push(this.get_item_data_with_id(item_id));
		//console.log(this.view_item);
	
    
  }
  get_item_data_with_id(item_id) {
		for (let i = 0; i < this.review.length; i++) {
			if (this.review[i].id == item_id) {
				return this.review[i];
			}
		}
	}
	methodFromParentView(cell, valls) {
		// Swal("View");
		console.log(valls);
		this.ViewItem(valls.id);
  }
  Save(){
    //console.log(this.rev);
    this.api.questionreview(this.qsnreview.id,this.reviewForm.value).subscribe(res => {
      //this.rev=res;
      if(res.status){
       Swal.fire('Success..',  'success'); 
       this.view_close();
      }else{
       Swal.fire('Oops...', 'error');
 
      }
 
     });
   }
  
  grid() {
   this.api.get_questionreview_data().subscribe((data) => {
    this.access = data.access;
     this.review=data.data
    // console.log(this.review);
     
   });
 }
 view_data(qr){
  this.viewSt = true;
  this.formstat = true;
  this.qsnreview = qr;
  qr.question_temp_remarks.forEach(element => {
    if(element.userId == this.publicapi.getUser().id){
      console.log('hii');
      this.formstat = false;
    }
  });
  console.log(this.formstat);
}

view_close(){
  this.viewSt =false;
  this.qsnreview =[];
  this.reviewForm.patchValue({status:'',remarks:''});
}
}
